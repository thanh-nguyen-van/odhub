<?
$username="root";
$password="";
$database="google_store";
?>