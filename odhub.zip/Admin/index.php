<?include('include/adminheader.php');?>
<?php
   // $siteURL = $siteURL
    
?>

	<!--Page under construction-->
    
    <h1>Welcome to OD HUB admin panel</h1>
    <div class="wht-bg">
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
    	
        <tr>
    		<td width="20%" align="center" valign="top" class="td-bor" style="border-left:1px solid #6d6d6d;">
            	<table cellpadding="0" cellspacing="0" border="0" width="100%">
                	<tr>
                    	<td align="left" valign="top" class="td-hd">HOME</td>
                    </tr>
                    <tr>
                    	<td align="left" valign="top"  style="background:#c5c5c5;"><a href="#">Settings</a></td>
                    </tr>
                    <tr>
                    	<td align="left" valign="top" style="background:#e6e6e6;"><a href="<?php echo $siteURL;?>ChangePassword.php">Change Password</a></td>
                    </tr>
                    <tr>
                    	<td align="left" valign="top" style="background:#e6e6e6;"><a href="<?php echo $siteURL;?>AddVideo.php">Add Video</a></td>
                    </tr>
                    <tr>
                    	<td align="left" valign="top"><a href="<?php echo $siteURL;?>ViewFeeDetail.php">Fees</a></td>
                    </tr>
                    <tr>
                    	<td align="left" valign="top"><a href="<?php echo $siteURL;?>ViewBidFeeDetail.php">Bid Fees</a></td>
                    </tr>
                    
                   
                     <tr>
                    	<td align="left" valign="top"><a href="<?php echo $siteURL;?>projectSkills.php">Project Skills</a></td>

                    </tr>
                    
                    <tr>
                    	<td align="left" valign="top" style="background:#c5c5c5;"><a href="#">Country State</a></td>

                    </tr>
                     <tr>
                    	<td   align="left" valign="top" style="background:#e6e6e6;"><a href="<?php echo $siteURL;?>CustomCountryListing.php">Country Management</a></td>
                    </tr>
                    
                     <tr>
                    	<td   align="left" valign="top" style="background:#e6e6e6;"><a href="<?php echo $siteURL;?>CustomStateListing.php">State Management</a></td>
                    </tr>
                    
                    
                    <tr>
                    	<td align="left" valign="top" style="background:#c5c5c5;"><a href="#">News</a></td>

                    </tr>
                    
                    <tr>
                    	<td   align="left" valign="top" style="background:#e6e6e6;"><a href="<?php echo $siteURL;?>ViewNews.php">Lists</a></td>
                    </tr>
                    <tr>
                    	<td   align="left" valign="top" style="background:#e6e6e6;"><a href="<?php echo $siteURL;?>AddNews.php">Add</a></td>
                    </tr>
                     <tr>
                    	<td align="left" valign="top"><a href="<?php echo $siteURL;?>SiteContent.php">Site Content</a></td>
                    </tr>
                   <tr>
                    	<td align="left" valign="top"><a href="<?php echo $siteURL;?>ViewTestimonials.php">Testimonials</a></td>
                    </tr>
                    <tr>
                    	<td align="left" valign="top"><a href="<?php echo $siteURL;?>ViewLeftMenu.php">Left Menu</a></td>
                    </tr>
                    <tr>
                    	<td align="left" valign="top"><a href="<?php echo $siteURL;?>PaypalSetting.php">Paypal Setting</a></td>
                    </tr>
                     <tr>
                    	<td align="left" valign="top"><a href="<?php echo $siteURL;?>SiteCommission.php">Site Commission</a></td>
                    </tr>
                     <tr>
                    	<td align="left" valign="top"><a href="<?php echo $siteURL;?>SitePaymentSetting.php">Site Payment Setting</a></td>
                    </tr>
                     <tr>
                    	<td  align="left" valign="top"><a href="<?php echo $siteURL;?>Client_home.php" >Home Content</a></td>
                    </tr>
                  
                    	<td  align="left" valign="top"><a href="<?php echo $siteURL;?>HomeVideo.php" >Home Video</a></td>
                    </tr>
                </table>
          </td>
          <td width="20%" align="center" valign="top" class="td-bor">
            	<table cellpadding="0" cellspacing="0" border="0" width="100%">
                	<tr>
                    	<td align="left" valign="top" class="td-hd">CLIENTS</td>
                    </tr>
                    <tr>
                    	<td  align="left" valign="top"><a href="<?php echo $siteURL;?>ViewClientList.php">Lists</a></td>
                    </tr>
                    <tr>
                    	<td  align="left" valign="top"><a href="<?php echo $siteURL;?>ViewClientFeedbacks.php" >Feedback</a></td>
                    </tr>
                    <tr>
                    	<td  align="left" valign="top"><a href="<?php echo $siteURL;?>ClientHome.php" >Home Page</a></td>
                    </tr>
                    <tr>
                    	<td  align="left" valign="top"><a href="<?php echo $siteURL;?>CloseCaseRequest.php" >Close Case Request</a></td>
                    </tr>
                    
                    
                    
                    
                    
                    
                </table>
          </td>
          <td width="20%" align="center" valign="top" class="td-bor">
            	<table cellpadding="0" cellspacing="0" border="0" width="100%">
                	<tr>
                    	<td align="left" valign="middle" class="td-hd">PROFESSIONALS</td>
                    </tr>
                    <tr>
                    	<td  align="left" valign="middle"><a href="<?php echo $siteURL;?>ViewLawyerList.php">Lists</a></td>
                    </tr>
                    <tr>
                    	<td  align="left" valign="middle"><a href="<?php echo $siteURL;?>ViewLawyerFeedbacks.php">Feedback</a></td>
                    </tr>
                    <tr>
                    	<td  align="left" valign="middle"><a href="<?php echo $siteURL;?>LawyerHome.php">Home Page</a></td>
                    </tr>
                    <tr>
                    	<td  align="left" valign="middle"><a href="<?php echo $siteURL;?>LawyerCategoryList.php">Category</a></td>
                    </tr>
                    <tr>
                    	<td  align="left" valign="top"><a href="<?php echo $siteURL;?>ProfessionalServices.php" >Professional Services </a></td>
                    </tr>
                </table>
          </td>
          <td width="20%" align="center" valign="top"  class="td-bor">
            	<table cellpadding="0" cellspacing="0" border="0" width="100%">
                	<tr>
                    	<td align="left" valign="middle" class="td-hd">PROJECTS</td>
                    </tr>
                    <tr>
                    	<td  align="left" valign="middle"><a href="<?php echo $siteURL;?>PostedProjects.php">PostedProjects</a></td>
                    </tr>
                    <tr>
                    	<td  align="left" valign="middle"><a href="<?php echo $siteURL;?>ActiveProjects.php">ActiveProjects</a></td>
                    </tr>
                    <tr>
                    	<td align="left" valign="middle"><a href="<?php echo $siteURL;?>ClosedProjects.php">ClosedProjects</a></td>
                    </tr>
                </table>
          </td>
          <td width="20%" align="center" valign="top"  class="td-bor">
            	<table cellpadding="0" cellspacing="0" border="0" width="100%">
                	<tr>
                    	<td align="left" valign="middle" class="td-hd">SUB-ADMIN</td>
                    </tr>
                    <tr>
                    	<td  align="left" valign="middle"><a href="<?php echo $siteURL;?>SubAdminList.php">List</a></td>
                    </tr>
                    <tr>
                    	<td  align="left" valign="middle"><a href="<?php echo $siteURL;?>/SubAdminAdd.php">Add</a></td>
                    </tr>
                </table>
          </td>
    	</tr>
    </table>
    </div>
	
<? include('include/adminfooter.php');?>