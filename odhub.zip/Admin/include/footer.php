<section class="blue-bg">
	<div class="container">
        <article class="left-part">
        	<h3>Latest News</h3>
            <ul>
            	<li><p><a href="#">Lorem Ipsum is simply dummy text</a></p> 
of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</li>
              <li><p><a href="#">Lorem Ipsum is simply dummy text</a></p> 
of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</li>
             <li class="more"><a href="#">More...</a></li>

            </ul>
        </article>
        <article class="right-part">
       	  <div class="v-txt">
           	<h3>Latest News</h3>
              Lorem Ipsum is simply dummy text of the printing and typesetting <br>
              <br>
            industry. 

Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
              <p class="more"><a href="#">More...</a></p>
          </div>
            <div class="video"><img src="<?php echo $publicURL;?>images/video.jpg" alt=""></div>
        </article>
        <div class="clear"></div>
    </div>
</section>
<footer class="footer">
	<div class="container">
       <div class="f-left"><a href="<?php echo $siteURL?>"><img src="<?php echo $publicURL;?>images/f-logo.png" alt="" width="168" height="55" border="0"></a></div>
      <div class="f-mid">
      	<div><a href="#">Home</a> <a href="AboutUs.php">About Us</a> <a href="Testimonials.php">Testimonials</a> <a href="TermsCondition.php">Terms of Service</a></div>
        <div class="copy">&copy; Copyright.All right reserved. Privacy Policy.Powered by <a href="http://arcinfotec.com" target="_blank" style="padding:0px; text-decoration:underline;">ArcInfotech</a></div>
      </div>
      <div class="f-right">
      <a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image17','','<?php echo $publicURL;?>images/s-icon1-h.png',1)"><img src="<?php echo $publicURL;?>images/s-icon1.png" name="Image17" width="24" height="30" border="0"></a>
      <a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image18','','<?php echo $publicURL;?>images/s-icon2-h.png',1)"><img src="<?php echo $publicURL;?>images/s-icon2.png" name="Image18" width="24" height="30" border="0"></a>
      <a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image19','','<?php echo $publicURL;?>images/s-icon3-h.png',1)"><img src="<?php echo $publicURL;?>images/s-icon3.png" name="Image19" width="24" height="30" border="0"></a></div>
      
      <div class="clear"></div>
  </div>
</footer>
</body>
</html>
