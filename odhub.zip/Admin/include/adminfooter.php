</div>
<!--<div class="footer">
<div id="copyright">Powered by <a href="http://arcinfotec.com" target="_blank" style="padding:0px; text-decoration:underline;">ArcInfotech</a></div>
</div>-->
<div class="footer" style="background:#000;">
	<div class="container">
       <div class="f-left"><a href="<?php echo $siteURL;?>"><img width="168" height="55" border="0" alt="" src="<?php echo $publicURL;?>images/f-logo2.png"></a></div>
      <div class="f-mid">
        <div class="copy">&copy; Copyright.All right reserved. Privacy Policy.Powered by <a style="padding:0px; text-decoration:underline;" target="_blank" href="http://arcinfotec.com">ArcInfotech</a></div>
      </div>
      
      
      <div class="clear"></div>
  </div>
</div>
</BODY>
</HTML>