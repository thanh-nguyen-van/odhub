<?php

	$table['video'] 			    = 'lm_video_tbl';
	$table['account'] 			    = 'lm_account_tbl';
	$table['adminaccount'] 			= 'lm_adminaccount_tbl';
	$table['alltransaction'] 		= 'lm_alltransaction_tbl';
	$table['bidfee'] 			    = 'lm_bidfee_tbl';
	$table['bid'] 			        = 'lm_bid_tbl';
	$table['blogcategory'] 			= 'lm_blogcategory_tbl';
	$table['blogcomment'] 			= 'lm_blogcomment_tbl';
	$table['blog'] 			        = 'lm_blog_tbl';
	$table['caseaddinfo'] 			= 'lm_caseaddinfo_tbl';
	$table['caseawarded'] 			= 'lm_caseawarded_tbl';
	$table['caseclosed'] 			= 'lm_caseclosed_tbl';
	$table['caseexpertise'] 		= 'lm_caseexpertise_tbl';
	$table['casemail'] 			    = 'lm_casemail_tbl';
	$table['casemilestonedetail'] 	= 'lm_casemilestonedetail_tbl';
	$table['casemilestone'] 		= 'lm_casemilestone_tbl';
	$table['casestatus'] 			= 'lm_casestatus_tbl';
	$table['case'] 			        = 'lm_case_tbl';
	$table['clarification'] 		= 'lm_clarification_tbl';
	$table['clientdetail'] 			= 'lm_clientdetail_tbl';
	$table['clientinvoice'] 		= 'lm_clientinvoice_tbl';
	$table['country'] 			    = 'lm_country_tbl';
	$table['currency'] 			    = 'lm_currency_tbl';
	$table['discussion'] 			= 'lm_discussion_tbl';
	$table['escrow'] 			    = 'lm_escrow_tbl';
	$table['eselectpayment'] 		= 'lm_eselectpayment_tbl';
	$table['expertise'] 			= 'lm_expertise_tbl';
	$table['faq'] 			        = 'lm_faq_tbl';
	$table['feedbackdetail'] 		= 'lm_feedbackdetail_tbl';
	$table['feedbackmaster'] 		= 'lm_feedbackmaster_tbl';
	$table['feedback'] 			    = 'lm_feedback_tbl';
	$table['commission'] 			= 'lm_commission_tbl';
	$table['forumpost'] 			= 'lm_forumpost_tbl';
	$table['forumtopic'] 			= 'lm_forumtopic_tbl';
	$table['lawyearinvite'] 		= 'lm_lawyearinvite_tbl';
	$table['lawyercategory'] 		= 'lm_lawyercategory_tbl';
	$table['lawyerdeposit'] 		= 'lm_lawyerdeposit_tbl';
	$table['professional_detail'] 	= 'lm_professionaldetail_tbl';
	$table['lawyerexpertise'] 		= 'lm_lawyerexpertise_tbl';
	$table['lawyerinvoice'] 		= 'lm_lawyerinvoice_tbl';
	$table['lawyersubscription'] 	= 'lm_lawyersubscription_tbl';
	$table['msg'] 			        = 'lm_msg_tbl';
	$table['news'] 			        = 'lm_news_tbl';
	$table['notification'] 			= 'lm_notification_tbl';
	$table['paymentpaypal'] 		= 'lm_paymentpaypal_tbl';
	$table['pmdetail'] 			    = 'lm_pmdetail_tbl';
	$table['pmmaster'] 			    = 'lm_pmmaster_tbl';
	$table['portfolio'] 			= 'lm_portfolio_tbl';
	$table['releaserequest'] 		= 'lm_releaserequest_tbl';
	$table['state'] 			    = 'lm_state_tbl';
	$table['staticpage'] 			= 'lm_staticpage_tbl';
	$table['subforum'] 			    = 'lm_subforum_tbl';
	$table['subscription'] 			= 'lm_subscription_tbl';
	$table['tax'] 			        = 'lm_tax_tbl';
	$table['topic'] 			    = 'lm_topic_tbl';
	$table['userstatus'] 			= 'lm_userstatus_tbl';
	$table['testimonials'] 			= 'lm_testimonials_tbl';
	$table['home'] 			        = 'im_home_page';
	$table['services'] 			    = 'im_service_list';
	$table['homevideo'] 			    = 'im_home_video';



?>
