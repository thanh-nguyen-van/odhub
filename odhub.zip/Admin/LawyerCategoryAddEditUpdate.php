<? include('include/adminheader.php'); ?>
<table width="100%">
<tr>
	<td colspan="5"><h3>Add/Edit Lawyer Category</h3></td>
</tr>
	<tr>
		<td><?php echo $msg; ?></td>
	</tr>
</table>
<?include('include/adminfooter.php');?>